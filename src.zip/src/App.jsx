import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GiBrain, GiClockwork, GiConfirmed } from 'react-icons/gi';

const GEMINI_API_KEY = 'AIzaSyByRxAkUcyXYgU2hHH6_B9Zyz34Q3qWoCM';
const HF_API_TOKEN = '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';

export default function App() {
  
  const [screen, setScreen] = useState('welcome');
  const [settings, setSettings] = useState({ topic: '', numQuestions: 5 });
  const [quizData, setQuizData] = useState([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [answer, setAnswer] = useState('');
  const [result, setResult] = useState(null);
  const [correctAnswer, setCorrectAnswer] = useState('');

  useEffect(() => {
    if (screen === 'quiz' && quizData.length > 0) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [screen, quizData]);

  const generateQuestion = async (topic) => {
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: `Create a question about ${topic} with 1-2 word answer. Format: Question: [question] Answer: [answer]`
              }]
            }]
          })
        }
      );
      const data = await response.json();
      const text = data.candidates[0].content.parts[0].text;
      return {
        question: text.split('Question:')[1].split('Answer:')[0].trim(),
        answer: text.split('Answer:')[1].trim().toLowerCase()
      };
    } catch (error) {
      return { question: 'Failed to load question', answer: 'error' };
    }
  };

  const generateImage = async (prompt) => {
    try {
      const response = await fetch(
        'https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2-1',
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${HF_API_TOKEN}` },
          body: JSON.stringify({ inputs: prompt }),
        }
      );
      const blob = await response.blob();
      return URL.createObjectURL(blob);
    } catch (error) {
      return '/fallback.jpg';
    }
  };

  const startQuiz = async () => {
    const questions = [];
    for (let i = 0; i < settings.numQuestions; i++) {
      const qna = await generateQuestion(settings.topic);
      const image = await generateImage(qna.answer);
      questions.push({ ...qna, image });
    }
    setQuizData(questions);
    setScreen('quiz');
  };

  const handleAnswer = () => {
    const isCorrect = answer.toLowerCase() === quizData[currentQ].answer;
    setResult(isCorrect);
    setCorrectAnswer(quizData[currentQ].answer);
    if (isCorrect) setScore(s => s + 1);
    
    setTimeout(() => {
      setResult(null);
      setAnswer('');
      setCorrectAnswer('');
      if (currentQ < settings.numQuestions - 1) {
        setCurrentQ(c => c + 1);
        setTimeLeft(30);
      } else {
        setScreen('result');
      }
    }, 1500);
  };

  return (
    <div className="container">
      <AnimatePresence mode='wait'>
        {screen === 'welcome' && (
          <motion.div
            key="welcome"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="welcome"
          >
            <GiBrain className="icon-main" />
            <h1>Visual Quiz Challenge</h1>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setScreen('setup')}
            >
              Start Now!
            </motion.button>
          </motion.div>
        )}

        {screen === 'setup' && (
          <motion.div
            key="setup"
            initial={{ x: 100 }}
            animate={{ x: 0 }}
            exit={{ x: -100 }}
            className="setup"
          >
            <GiClockwork className="icon-sub" />
            <h2>Quiz Setup</h2>
            <input
              type="text"
              placeholder="Enter Topic (e.g. Space, Animals)"
              value={settings.topic}
              onChange={(e) => setSettings(s => ({ ...s, topic: e.target.value }))}
            />
            <input
              type="number"
              min="1"
              value={settings.numQuestions}
              onChange={(e) => setSettings(s => ({ ...s, numQuestions: e.target.value }))}
            />
            <div className="button-group">
              <button onClick={() => setScreen('welcome')}>Back</button>
              <button onClick={startQuiz}>Start Quiz</button>
            </div>
          </motion.div>
        )}

        {screen === 'quiz' && quizData[currentQ] && (
          <motion.div
            key="quiz"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="quiz"
          >
            <div className="header">
              <div className="score">Score: {score}</div>
              <div className="timer">{timeLeft}s</div>
            </div>
            
            <motion.div
              key={currentQ}
              initial={{ y: 20 }}
              animate={{ y: 0 }}
              className="question-card"
            >
              <h3>{quizData[currentQ].question}</h3>
              <img src={quizData[currentQ].image} alt="Visual clue" />
              <div className="answer-box">
                <input
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAnswer()}
                  placeholder="Type your answer..."
                />
                <button onClick={handleAnswer}>Submit</button>
              </div>
              {result !== null && (
                <div className={`result ${result ? 'correct' : 'incorrect'}`}>
                  {result ? '🎉 Correct!' : `❌ Incorrect! The correct answer is: ${correctAnswer}`}
                </div>
              )}
            </motion.div>
          </motion.div>
        )}

        {screen === 'result' && (
          <motion.div
            key="result"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="result-screen"
          >
            <GiConfirmed className="icon-main" />
            <h2>Quiz Complete!</h2>
            <p>Final Score: {score}/{settings.numQuestions}</p>
            <button onClick={() => {
              setScreen('welcome');
              setCurrentQ(0);
              setScore(0);
            }}>Play Again</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}